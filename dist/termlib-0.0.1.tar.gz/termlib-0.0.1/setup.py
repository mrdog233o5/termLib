from setuptools import setup, find_packages

setup(
    name="termlib",
    version="0.0.1",
    packages=find_packages(),
    install_requires=[],
    author="mrdog233o5",
    description="some terminal tools",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown"
)
